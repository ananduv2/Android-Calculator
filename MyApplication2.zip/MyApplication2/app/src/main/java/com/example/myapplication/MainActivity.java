package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.view.View;
import android.view.View.OnClickListener;


public class MainActivity extends AppCompatActivity {


   private EditText mEditText1;
   private EditText mEditText2;
   private TextView mTextViewResult;
   private Button mButtonAdd;
   private Button mButtonSub;
   private Button mButtonMul;
   private Button mButtonDiv;
   private Button mButtonClr;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mEditText1=findViewById(R.id.edittext_number_1);
        mEditText2=findViewById(R.id.edittext_number_2);
        mTextViewResult=findViewById(R.id.textview_result);
        mButtonAdd=findViewById(R.id.button_add);
        mButtonSub=findViewById(R.id.button_sub);
        mButtonMul=findViewById(R.id.button_mul);
        mButtonDiv=findViewById(R.id.button_div);
        mButtonClr=findViewById(R.id.button_clr);

        mButtonAdd.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if (mEditText1.getText().toString()=="0"){
                    mEditText1.setText("0");

                }
                if (mEditText2.getText().toString()=="0"){
                    mEditText2.setText("0");

                }

                double num1=Integer.parseInt(mEditText1.getText().toString());
                double num2=Integer.parseInt(mEditText2.getText().toString());
                double sum=num1+num2;
                mTextViewResult.setText(String.valueOf(sum));
            }
        });

        mButtonSub.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if (mEditText1.getText().toString()=="0"){
                    mEditText1.setText("0");

                }
                if (mEditText2.getText().toString()=="0"){
                    mEditText2.setText("0");

                }

                int num1=Integer.parseInt(mEditText1.getText().toString());
                int num2=Integer.parseInt(mEditText2.getText().toString());
                int sum=num1-num2;
                mTextViewResult.setText(String.valueOf(sum));
            }
        });
        mButtonMul.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if (mEditText1.getText().toString()=="0"){
                    mEditText1.setText("0");

                }
                if (mEditText2.getText().toString()=="0"){
                    mEditText2.setText("0");

                }

                int num1=Integer.parseInt(mEditText1.getText().toString());
                int num2=Integer.parseInt(mEditText2.getText().toString());
                int sum=num1*num2;
                mTextViewResult.setText(String.valueOf(sum));
            }
        });
        mButtonDiv.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if (mEditText1.getText().toString()=="0"){
                    mEditText1.setText("0");

                }
                if (mEditText2.getText().toString()=="0"){
                    mEditText2.setText("0");

                }

                int num1=Integer.parseInt(mEditText1.getText().toString());
                int num2=Integer.parseInt(mEditText2.getText().toString());
                int sum=num1/num2;
                mTextViewResult.setText(String.valueOf(sum));
            }
        });
        mButtonClr.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                    mEditText1.setText("0");
                    mEditText2.setText("0");
                mTextViewResult.setText("0");
            }
        });
    }
}
